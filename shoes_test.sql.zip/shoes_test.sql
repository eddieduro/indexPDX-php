-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Mar 04, 2016 at 04:47 PM
-- Server version: 5.7.10
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shoes_test`
--
CREATE DATABASE IF NOT EXISTS `shoes_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoes_test`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`) VALUES
(409, 'adidas'),
(410, 'adidas');

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `stores_brands`
--

CREATE TABLE `stores_brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `store_id` int(11) DEFAULT NULL,
  `brand_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stores_brands`
--

INSERT INTO `stores_brands` (`id`, `store_id`, `brand_id`) VALUES
(1, 12, 32),
(2, 93, 105),
(3, 99, 111),
(4, 106, 117),
(5, 113, 123),
(6, 120, 129),
(7, 121, 130),
(8, 127, 136),
(9, 128, 137),
(10, 134, 143),
(11, 135, 144),
(12, 141, 150),
(13, 142, 151),
(14, 148, 157),
(15, 149, 158),
(16, 155, 164),
(17, 156, 165),
(18, 162, 171),
(19, 163, 172),
(20, 169, 178),
(21, 170, 179),
(22, 176, 185),
(23, 177, 186),
(24, 183, 192),
(25, 184, 193),
(26, 190, 199),
(27, 191, 200),
(28, 197, 206),
(29, 198, 207),
(30, 204, 213),
(31, 205, 214),
(32, 211, 220),
(33, 212, 221),
(34, 218, 227),
(35, 219, 228),
(36, 225, 234),
(37, 226, 235),
(38, 232, 241),
(39, 233, 242),
(40, 239, 248),
(41, 240, 249),
(42, 246, 255),
(43, 247, 256),
(44, 253, 262),
(45, 254, 263),
(46, 260, 269),
(47, 261, 270),
(48, 267, 276),
(49, 268, 277),
(50, 274, 283),
(51, 275, 284),
(52, 281, 290),
(53, 282, 291),
(54, 288, 297),
(55, 289, 298),
(56, 295, 304),
(57, 296, 305),
(58, 302, 311),
(59, 303, 312),
(60, 309, 318),
(61, 310, 319),
(62, 318, 325),
(63, 319, 326),
(64, 322, 327),
(65, 328, 333),
(66, 329, 334),
(67, 332, 335),
(68, 338, 341),
(69, 339, 342),
(70, 342, 343),
(71, 348, 349),
(72, 349, 350),
(73, 352, 351),
(74, 358, 357),
(75, 359, 358),
(76, 362, 359),
(77, 368, 365),
(78, 369, 366),
(79, 372, 367),
(80, 378, 374),
(81, 379, 375),
(82, 382, 376),
(83, 388, 383),
(84, 389, 384),
(85, 392, 385),
(86, 398, 392),
(87, 399, 393),
(88, 402, 394),
(89, 404, 408),
(90, 410, 409),
(91, 411, 410),
(92, 414, 411);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores_brands`
--
ALTER TABLE `stores_brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=412;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=415;
--
-- AUTO_INCREMENT for table `stores_brands`
--
ALTER TABLE `stores_brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
